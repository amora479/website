main()
{
   printf("This is a line of text to output.\n");
   printf("And this is another ");
   printf("line of text.\n\n");
   printf("This is a third line.\n");
}
