                       PLAFORMTRON ver 1.00
                  Copyright 1997 Thanasis Liouros


Welcome to this powerfull game library.
With PLATFORMTRON you can create amazing professional games
very easy without having to wonder about hardware details or other
details like how the sprites are displayed or clipped, how the scrolling
is done , etc. To see what i mean here are some of PLATFORMTRON features:

- 320x200x256 modex graphic mode
- smooth animation at 70 frames/sec
- smooth scrolling to a maximum of 280 pixels/sec in each direction.
- extendable from the user (c++)
- complete 'world' support which includes:
  - built in scrolling routines
  - multiple layers for easy background creation
  - built in background<->sprites interaction support
  - full sprites support , automating clipping ,drawing and handling
  - sprites pseudo layers
  - collision detection routine
  - high transparency to the user
- complete sprites/objects support:
  - action functions for easy and fast animation.
  - various flags that can alter the sprite activity
  - fully customizable behaviour that can perform any activity related
    to sprites or not
- excellent low level keyboard handler
- excellent timer handlers
- various vga routines
- WINDOWS 95 compatibility
- EMS support


See the demo program to get a first taste of PLATFORMTRON features.




