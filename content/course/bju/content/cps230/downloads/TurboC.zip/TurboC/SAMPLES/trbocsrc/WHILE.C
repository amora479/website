                                         /* Chapter 3 - Program 1 */
/* This is an example of a "while" loop */

main()
{
int count;

   count = 0;
   while (count < 6) {
      printf("The value of count is %d\n",count);
      count = count + 1;
   }
}
