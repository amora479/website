/* ---- poetry.c ------ */

#include "twindow.h"
void poems(void);

main()
{
	load_help("tcprogs.hlp");
	poems();
}


