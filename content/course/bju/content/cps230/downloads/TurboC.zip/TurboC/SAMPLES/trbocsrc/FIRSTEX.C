main()
{
int index;

   for (index = 0;index < 7;index = index + 1)
      printf("First example program.\n");
}
