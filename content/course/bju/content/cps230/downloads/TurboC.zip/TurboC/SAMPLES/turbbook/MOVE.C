/* ------ move.c ------ */

void testmove(void);

main()
{
	testmove();
}

